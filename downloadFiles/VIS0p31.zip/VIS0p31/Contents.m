% VIS toolbox
% Version 0.31		29-Oct-2007
% Copyright (c) 2007, Neil D. Lawrence
% 
, Neil D. Lawrence
% SCANALYZELOG2 Helper function to get log2 ratio from a scanalyze file
% DEMPAPER1 This script recreates the first Bioinformatics paper experiment.
% BLOCKNEIGHBOURS Block out regions in the likelihood image.
% MODELDATAHIST Model the foreground and background with a histogram.
% INDHISTOGLL Compute the log-likelihood of a histogram, assuming data is indpendently sampled.
% EXTRACTRATIOS Function for extracting log ratios associated with ovals.
% OVALPAK Takes the parameters of a set of ovals and returns the ovals.
% DEMPAPER2 This script recreates a Bioinformatics paper experiment.
% OVALVISAMPLER Use the variational importance sampler to refine the oval positions.
% SPOTLOG2 Helper function to get log2 ratio from a spot file.
% OVALSAMPLE Sample an oval.
% VISAMPLER The variational imporatnce sampler.
% SAGGRIDPOINTS Extracts the centres of the ovals from scanalyze grids.
% HISTOGCREATE Creates a histogram between a specified range.
% CREATEGRIDMODEL Obtain foreground and background likelihoods for pixels in the grid.
% PROCESSIMAGE processes a cDNA microarray image.
% MODELDATALNNORM Model the foreground and background with a log normal.
% OVALLIKELIHOOD Computes the likelihood of an oval given an integral image.
% OBJECTPAK Take an object's parameters and create objects from them.
% MICROARRAYOVALS Plot progress of oval sampling for demos.
% SAGGRIDDRAW Draws a grid of the Scanalyze format.
% PREPAREPLOT Helper function for tidying up the plot before printing.
% SAGWRITE this function takes a grid from matlab and writes it to a scanalyze grid file.
% VISTOOLBOXES Toolboxes needed for running the VIS software.
% SAGREAD This function loads a scanalyze SAG file into a structure in MATLAB.
% OVALLL Evaluate the log likelihood of hypothesised ovals.
% RATIOCSVWRITE Takes a structure giving results and writes to a csv file.
% SAGGRID2OVAL Converts a saggrid into ovals.
% DEMSAMPLE This script visualises the algorithm as it runs.
% OVALUNPAK Take an array of ovals and convert into a matrix of their parameters.
% OVALSUBSCRIPT Returns the subscripts of any pixels that would fall inside the oval
% DEMPAPER3 This script recreates a Bioinformatics paper experiment.
% OBJECTUNPAK Take an object's parameters and create objects from them.
