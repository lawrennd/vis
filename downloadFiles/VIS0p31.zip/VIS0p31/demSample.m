
% DEMSAMPLE This script visualises the algorithm as it runs.
%
%	Description:
%	% 	demSample.m version 1.1


% This script runs the vis algorithm on the first grid visualising the
% samples as it runs.
clf
[answer, saggrid] = processImage('./data/SS1', 2, 1);