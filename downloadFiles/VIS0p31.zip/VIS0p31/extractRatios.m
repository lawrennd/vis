function [ratios, log2Ratios, redValues, greenValues, redBackground, greenBackground] = extractRatios(ovals, currentImage, maxWidth);

% EXTRACTRATIOS Function for extracting log ratios associated with ovals.
%
%	Description:
%	
%	[ratios, log2Ratios, redValues, greenValues, redBackground,
%	greenBackground] = extractRatios(ovals, currentImage, maxWidth);
%	
%	This function is implemented as a mex file. See extractRatios.cpp
%	
%	version 0.1
%	Copyright (c) Neil Lawrence 2002
% 	extractRatios.m version 1.2

  
