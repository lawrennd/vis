function ll = modelDataLnNorm(channelOne, channelTwo, index, gridSize, display);

% MODELDATALNNORM Model the foreground and background with a log normal.
%
%	Description:
%
%	LL = MODELDATALNNORM(CHANNELONE, CHANNELTWO, INDICES, GRIDSIZE,
%	DISPLAY) models the foreground pixel intensities and background
%	pixel intensities with log normals.
%	 Returns:
%	  LL - the log likelihood
%	 Arguments:
%	  CHANNELONE - the red channel.
%	  CHANNELTWO - the green channel.
%	  INDICES - indices from the channels to be modelled.
%	  GRIDSIZE - size of the original grid being modelled (rows and
%	   columns).
%	  DISPLAY - should be set to 0 for no display, 1 for text display
%	   and 2 for image display. The latter setting is useful for ensuring
%	   you have the parameters of the variational importance sampler set
%	   reasonably.
%	
%
%	See also
%	CREATEGRIDMODEL, MODELDATAHIST


%	Copyright (c) 2007 Neil D. Lawrence
% 	modelDataLnNorm.m version 1.1


I_max = 65535;


% Build the channel models
logSelectChannelOne = log(double(channelOne(index))+1);
muOne = mean(logSelectChannelOne);
varOne = var(logSelectChannelOne);

logSelectChannelTwo = log(double(channelTwo(index))+1);
muTwo = mean(logSelectChannelTwo);
varTwo = var(logSelectChannelTwo);

% Evaluate the likelihood
logChannelOne = log(double(channelOne)+1);
logChannelTwo = log(double(channelTwo)+1);
ll = -log(2*pi) - 1/2*log(varOne) -1/2*log(varTwo) ...
     - logChannelOne - logChannelTwo ...
     - 1/(2*varOne)*(logChannelOne - muOne).^2 ...
     - 1/(2*varTwo)*(logChannelTwo - muTwo).^2;

ll = reshape(ll, gridSize)';
