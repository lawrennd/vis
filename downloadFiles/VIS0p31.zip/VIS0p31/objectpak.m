function objects = objectpak(params, object)

% OBJECTPAK Take an object's parameters and create objects from them.
%
%	Description:
%	objects = objectpak(params, object)
%% 	objectpak.m version 1.2


objects = feval([object.type 'pak'], params, object);

