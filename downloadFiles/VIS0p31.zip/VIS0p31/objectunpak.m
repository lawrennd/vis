function params = objectunpak(object)

% OBJECTUNPAK Take an object's parameters and create objects from them.
%
%	Description:
%	params = objectunpak(object)
%% 	objectunpak.m version 1.2


params = feval([object.type 'unpak'], object);

