function ll = ovalLikelihood(params, oval, likelihoodStruct);

% OVALLIKELIHOOD Computes the likelihood of an oval given an integral image.
%
%	Description:
%
%	LL = OVALLIKELIHOOD(PARAMS, OVAL, LIKELIHOODSTRUCT) returns the
%	likelihood associated with a set of ovals.
%	 Returns:
%	  LL - the returned log likelihood.
%	 Arguments:
%	  PARAMS - the parameters of the ovals.
%	  OVAL - the structure of the ovals.
%	  LIKELIHOODSTRUCT - the likelihood structure to be passed on to
%	   ovalll.
%	
%
%	See also
%	OVALLL


%	Copyright (c) 2007 Neil D. Lawrence
% 	ovalLikelihood.m version 1.1

  
for i = 1:size(params, 1)
  ovals(i) = ovalpak(params(i, :), oval);
end
% Call c++ function for speed.
ll = ovalll(ovals, likelihoodStruct);
