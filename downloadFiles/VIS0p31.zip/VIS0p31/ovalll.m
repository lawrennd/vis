function sampl = ovalll(ovals, limitsx, limitsy,  redChannel, greenChannel, redbackHist, ...
		     greenbackHist, redforeHist, greenforeHist)

% OVALLL Evaluate the log likelihood of hypothesised ovals.
%
%	Description:
%
%	OVALLL(OVALS, LIMITSX, LIMITSY, REDCHANNEL, GREENCHANNEL,
%	REDBACKHIST, GREENBACKHIST, REDFOREHIST, GREENFOREHIST) evaluates
%	the log lieklihood of a set of hypothesised ovals.
%	 Arguments:
%	  OVALS - structure containing ovals to evaluate.
%	  LIMITSX - together with limitsy specifies the region of the image
%	   in which the oval is expected.
%	  LIMITSY - together with limitsx specifies the region of the image
%	   in which the oval is expected.
%	  REDCHANNEL - the red channel from the array image
%	  GREENCHANNEL - the green channel from the array image
%	  REDBACKHIST - a histogram representing the red background
%	  GREENBACKHIST - a histogram representing the green background
%	  REDFOREHIST - a histogram representing the red foreground
%	  GREENFOREHIST - a histogram representing the green foreground
%	This function is implemented as a mex file. See ovalll.cpp
%	
%	
%
%	See also
%	OVALLIKELIHOOD


%	Copyright (c) 2007 Neil D. Lawrence
% 	ovalll.m version 1.1


