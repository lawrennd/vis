% Microarray VIS Toolbox
% Version 0.1 	 24-Dec-2002
%
% Copyright (c) Neil Lawrence 2002
%
% DEMOSAMPLE Run the vis algorithm on the first grid with a image displayed.
% DEMOPAPER1 Check the consistency of the vis algorithm.
% DEMOPAPER2 Run the vis algorithm and compare replicates from the slide.
% EXTRACTRATIOS Function for extracting log ratios associated with ovals.
% MICROARRAYOVALS This function does the variational importance sampling.
% OBJECTDELETE Clear up the graphics that portray an object.
% OVALCREATE Create a struct containing the parameters of an oval.
% OVALDRAW Function for drawing an oval from an array of oval structures.
% OVALLL Evaluate the log likelihood of hypothesised ovals.
% OVALSUBSCRIPT Returns the subscripts of any pixels that would fall inside the oval.
% PREPAREPLOT Helper function for tidying up a plot before printing.
% PROCESSIMAGE This function processes a cDNA microarray image.
% RATIOCSVWRITE Takes a structure giving results and writes to a csv file.
% SAGGRID2OVALS Converts a saggrid into ovals.
% SAGGRIDPOINTS Extracts the centres of the ovals from scanalyze grids.
% SAGREAD This function loads a scanalyze SAG file into a structure in matlab
% SAGWRITE this function takes a grid from matlab and writes it to a scanalyze grid file.
% SCANALYZELOG2 Helper function to get log2 ratio from a scanalyze file
% ZEROAXES A function to move the axes crossing point to the origin.
