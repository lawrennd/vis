% This script runs the vis algorithm on the first grid visualising the
% samples as it runs.
clf
[answer, saggrid] = processImage('ss1', 2, 1);
