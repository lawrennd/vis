function [histog, logLikelihood]= pwhistogcreate(data, start, finish, nbins, ...
					       posterior, residCounts)


histog.ncentres = nbins;
[histog.height, histog.centres, histog.width] = pwhist(data, start, finish, ...
						  nbins, posterior);
%histog.height = histog.height+1/100*sum(histog.height);
histog.height = histog.height/sum(histog.height);
histog.height = histog.height/histog.width;
if nargout > 1
  logLikelihood  =log( histogprob(histog, data));
end
