function points = saggridpoints(saggrids)


% SAGGRIDPOINTS Extracts the centres of the ovals from scanalyze grids.

% points = saggridpoints(saggrids) This function takes an array of
% structures which represents grids in the scanalyze grid format and
% extracts the centres of the ovals into 2xN array, where N is the total
% number of ovals.
%
% version 0.1 
% Copyright (c) Neil Lawrence 2002

numPoints = 0;
for i = 1:length(saggrids)
  numPoints = numPoints + saggrids(i).columns*saggrids(i).rows;
end

points = zeros(numPoints, 2);

for gridNo = 1:length(saggrids)
  numRows = saggrids(gridNo).rows;
  numColumns = saggrids(gridNo).columns;
  counter = 0;
  for i = 1:numRows
    for j = 1:numColumns
      counter = counter + 1;
      rows = (i-1) + saggrids(gridNo).rowOffset(j, i)/100;
      columns = (j-1) + saggrids(gridNo).columnOffset(j, i)/100;
      points(counter, 1) = saggrids(gridNo).left ...
	  + rows*saggrids(gridNo).rowX ...
	  + columns*saggrids(gridNo).colX;
      points(counter, 2) = saggrids(gridNo).top ...
	  + rows*saggrids(gridNo).rowY ...
	  + columns*saggrids(gridNo).colY;
    end
  end
end


