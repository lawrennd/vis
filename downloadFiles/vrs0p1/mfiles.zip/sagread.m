function grid = sagread(filename)

% SAGREAD This function loads a scanalyze SAG file into a structure in matlab
%
% grid = sagread(filename)
%
% version 0.1 
% Copyright (c) Neil Lawrence 2002

fid = fopen(filename, 'r', 'ieee-le');
header = fread(fid, 6, 'uchar');
header = char(header');

switch header

 case 'SGF3.1'
  numGrids = fread(fid, 1, 'int32');
  for i = 1:numGrids
    grid(i).columns = fread(fid, 1, 'int32');
    grid(i).rows = fread(fid, 1, 'int32');
    grid(i).spotWidth = fread(fid, 1, 'int32');
    grid(i).spotHeight = fread(fid, 1, 'int32');
    grid(i).left = fread(fid, 1, 'double');
    grid(i).top = fread(fid, 1, 'double');
    grid(i).colX = fread(fid, 1, 'double');
    grid(i).colY = fread(fid, 1, 'double');
    grid(i).rowX = fread(fid, 1, 'double');
    grid(i).rowY = fread(fid, 1, 'double');
    grid(i).rowOffset = zeros(grid(i).rows, grid(i).columns);
    grid(i).columnOffset = zeros(grid(i).rows, grid(i).columns);
    grid(i).widthOverride = zeros(grid(i).rows, grid(i).columns);
    grid(i).heightOverride = zeros(grid(i).rows, grid(i).columns);
    grid(i).flag = zeros(grid(i).rows, grid(i).columns);
    for k=1:grid(i).columns
      for j=1:grid(i).rows
	grid(i).rowOffset(j, k) = fread(fid, 1, 'int32');
	grid(i).columnOffset(j, k) = fread(fid, 1, 'int32');
	grid(i).widthOverride(j, k) = fread(fid, 1, 'int32');
	grid(i).heightOverride(j, k) = fread(fid, 1, 'int32');
	grid(i).flag(j, k) = fread(fid, 1, 'int32');
      end
    end
  end

 otherwise
  error('Unrecognised file type')
end
fclose(fid);






