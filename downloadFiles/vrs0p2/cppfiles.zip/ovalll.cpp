/* version 0.1 Copyright (c) Neil Lawrence 2002 */

#include "mex.h"
#include <cmath>
//#include <cassert>

const double MAX_INTENSITY = 65535.0;
const double NEGLOGMAX = -log(MAX_INTENSITY);
const double LOGOFZERO = -328.0;
const double EPS = 1e-16;


double histogll(const double x, 
                const double* heights, 
                const double* centres, 
                const double width,
                const int nbins) 
{
  // histogll Gives the log-likelhood for a data-point under a histogram.
    
  for(int i = 0; i<nbins; i++) {
    if(x >= centres[i] - width/2 &&
       x < centres[i] + width/2) 
      {
        if(heights[i] == 0)
          return LOGOFZERO;  // return LOGOFZERO
        else
          return log(heights[i]);
      }
  }
  return LOGOFZERO; // data-point is not in histogram return LOGOFZERO
}


void ovalll(double* logLikelihoods,
            const int numOvals,
            const double centre[],
            const double xradius[],
            const double yradius[],
            const double limitsx[],
            const double limitsy[],
            const unsigned short redData[],
            const unsigned short greenData[],
            const int imageRows,
            const int imageCols,
            const double* redbackgroundHeights, 
            const double* redbackgroundCentres, 
            const double redbackgroundWidth, 
            const int redbackgroundBins,
            const double* greenbackgroundHeights, 
            const double* greenbackgroundCentres, 
            const double greenbackgroundWidth, 
            const int greenbackgroundBins,
            const double* redforegroundHeights, 
            const double* redforegroundCentres, 
            const double redforegroundWidth, 
            const int redforegroundBins,
            const double* greenforegroundHeights, 
            const double* greenforegroundCentres, 
            const double greenforegroundWidth, 
            const int greenforegroundBins)

{
  // Box location should be laid out as top left point, bottom right
  int boxLeftMost = (int)floor(limitsx[0]);
  int boxTopMost = (int)floor(limitsy[0]);
  int boxRightMost = (int)ceil(limitsx[1]);
  int boxBottomMost = (int)ceil(limitsy[1]);
  int boxNumRows = boxBottomMost - boxTopMost + 1;
  int boxNumCols = boxRightMost - boxLeftMost + 1;
  
  double* backgroundLl = (double*)mxMalloc(boxNumRows*boxNumCols*sizeof(double));
  double* foregroundLl = (double*)mxMalloc(boxNumRows*boxNumCols*sizeof(double));
  
  int y = 0;
  int x = 0;
  for(int i = 0; i < boxNumRows; i++) {
    y = i + boxTopMost;
    for(int j = 0; j < boxNumCols; j++) {
      x = j + boxLeftMost;
      // find the log-likelihood of the background
      backgroundLl[i + boxNumRows*j] = 
        histogll(redData[y-1 + imageRows*(x-1)], 
                 redbackgroundHeights, 
                 redbackgroundCentres, 
                 redbackgroundWidth, 
                 redbackgroundBins) 
        + histogll(greenData[y-1 + imageRows*(x-1)], 
                   greenbackgroundHeights, 
                   greenbackgroundCentres, 
                   greenbackgroundWidth, 
                   greenbackgroundBins);
      // find the log-likelihood of the foreground
      foregroundLl[i + boxNumRows*j] = 
        histogll(redData[y-1 + imageRows*(x-1)],
                 redforegroundHeights, 
                 redforegroundCentres, 
                 redforegroundWidth, 
                 redforegroundBins)
        + histogll(greenData[y-1 + imageRows*(x-1)], 
                   greenbackgroundHeights,
                   greenbackgroundCentres,
                   greenbackgroundWidth,
                   greenbackgroundBins);
    }
  }
  
  for(int ovalNo = 0; ovalNo < numOvals; ovalNo++) {
    // get the pixels associated with the oval
    logLikelihoods[ovalNo] = 0;
    double xRadius2 = xradius[ovalNo]*xradius[ovalNo];
    double yRadius2 = yradius[ovalNo]*yradius[ovalNo];
    
    for(int j = 0; j < boxNumCols; j++) {
      x = j + boxLeftMost;
      double xPos = (double)x - centre[ovalNo];
      double xPart = (xPos*xPos)/xRadius2;
      for(int i = 0; i < boxNumRows; i++) {
        y = i + boxTopMost;
        if(xPart <= 1) { 
          double yPos = (double)y - centre[ovalNo + numOvals];
          double yPart = (yPos*yPos)/yRadius2;
          // check if it is in oval or not and add to log likelihood.
          // no point in further checks if xPart > 1
          if(xPart + yPart <= 1) 
            logLikelihoods[ovalNo] += foregroundLl[i + boxNumRows*j];
          else 
            logLikelihoods[ovalNo] += backgroundLl[i + boxNumRows*j];
        }
        else
          logLikelihoods[ovalNo] += backgroundLl[i + boxNumRows*j];
      }
      
    }
  }
  mxFree(backgroundLl);
  mxFree(foregroundLl);
}


void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[])
{

  
  // ovals - struct, the structure containing the ovals
  if(mxGetClassID(prhs[0]) != mxSTRUCT_CLASS)
    mexErrMsgTxt("Error ovals should be STRUCT");  
  const int* ovalDims = mxGetDimensions(prhs[0]);
//  const mxArray ovalsType = mxGetField(prhs[0], 0, "type");
  const int numOvals = mxGetNumberOfElements(prhs[0]);
  double* centre = (double*)mxMalloc(2*numOvals*sizeof(double));
  double* xradius = (double*)mxMalloc(numOvals*sizeof(double));
  double* yradius = (double*)mxMalloc(numOvals*sizeof(double));
  double* centrePr;
  double* xradiusPr;
  double* yradiusPr;
  double* temp;
  for(int i = 0; i < numOvals; i++) {
    centrePr = mxGetPr(mxGetField(prhs[0], i, "centre"));
    xradiusPr = mxGetPr(mxGetField(prhs[0], i, "xradius"));
    yradiusPr = mxGetPr(mxGetField(prhs[0], i, "yradius"));
    
    xradius[i] = *xradiusPr;
    yradius[i] = *yradiusPr;

    for(int j = 0; j < 2; j++) 
      centre[i + j*numOvals] = centrePr[j];
  }  
  // limitsx - double, the limits of the rectangle in the x direction
  if(mxGetClassID(prhs[1]) != mxDOUBLE_CLASS)
    mexErrMsgTxt("Error limitsx should be DOUBLE");  
  double* limitsx = mxGetPr(prhs[1]);

  // limitsy - double, the limits of the rectangle in the y direction
  if(mxGetClassID(prhs[2]) != mxDOUBLE_CLASS)
    mexErrMsgTxt("Error limitsy should be DOUBLE");  
  double* limitsy = mxGetPr(prhs[2]);
  
  // redData is assumed to be uint16
  if(mxGetClassID(prhs[3]) != mxUINT16_CLASS)
    mexErrMsgTxt("Error red channel data should be UINT16");  
  unsigned short *redData = (unsigned short *)mxGetData(prhs[3]);
  const int *imageDims;
  imageDims = mxGetDimensions(prhs[3]);
  int imageRows = imageDims[0];
  int imageCols = imageDims[1];

  // greenData is assumed to be uint16
  if(mxGetClassID(prhs[4]) != mxUINT16_CLASS)
    mexErrMsgTxt("Error green channel data should be UINT16");  
  unsigned short *greenData = (unsigned short *)mxGetData(prhs[3]);



  if(mxGetClassID(prhs[5]) != mxSTRUCT_CLASS)
    mexErrMsgTxt("Error red background histogram should be struct");  
  double* redbackgroundCentres = mxGetPr(mxGetField(prhs[5], 0, "centres"));
  double* redbackgroundHeights = mxGetPr(mxGetField(prhs[5], 0, "height"));
  double redbackgroundWidth = *mxGetPr(mxGetField(prhs[5], 0, "width"));
  int redbackgroundBins = (int)(*mxGetPr(mxGetField(prhs[5], 0, "ncentres")));

  if(mxGetClassID(prhs[6]) != mxSTRUCT_CLASS)
    mexErrMsgTxt("Error green background histogram should be struct");  
  double* greenbackgroundCentres = mxGetPr(mxGetField(prhs[6], 0, "centres"));
  double* greenbackgroundHeights = mxGetPr(mxGetField(prhs[6], 0, "height"));
  double greenbackgroundWidth = *mxGetPr(mxGetField(prhs[6], 0, "width"));
  int greenbackgroundBins = (int)(*mxGetPr(mxGetField(prhs[6], 0, "ncentres")));

  if(mxGetClassID(prhs[7]) != mxSTRUCT_CLASS)
    mexErrMsgTxt("Error foreground histogram should be struct");  
  double* redforegroundCentres = mxGetPr(mxGetField(prhs[7], 0, "centres"));
  double* redforegroundHeights = mxGetPr(mxGetField(prhs[7], 0, "height"));
  double redforegroundWidth = *mxGetPr(mxGetField(prhs[7], 0, "width"));
  int redforegroundBins = (int)(*mxGetPr(mxGetField(prhs[7], 0, "ncentres")));

  if(mxGetClassID(prhs[8]) != mxSTRUCT_CLASS)
    mexErrMsgTxt("Error foreground histogram should be struct");  
  double* greenforegroundCentres = mxGetPr(mxGetField(prhs[8], 0, "centres"));
  double* greenforegroundHeights = mxGetPr(mxGetField(prhs[8], 0, "height"));
  double greenforegroundWidth = *mxGetPr(mxGetField(prhs[8], 0, "width"));
  int greenforegroundBins = (int)(*mxGetPr(mxGetField(prhs[8], 0, "ncentres")));


  int dims[2];
  dims[0] = numOvals;
  dims[1] = 1;
  plhs[0] = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
  double* logLikelihoods = mxGetPr(plhs[0]);
  
  
  //mexPrintf("There are %d ovals.\n", numOvals);
  ovalll(logLikelihoods, numOvals, centre, xradius, yradius, limitsx, limitsy, redData, greenData, imageRows, imageCols, 
         redbackgroundHeights, redbackgroundCentres, 
         redbackgroundWidth, redbackgroundBins,
         greenbackgroundHeights, greenbackgroundCentres, 
         greenbackgroundWidth, greenbackgroundBins,
         redforegroundHeights, redforegroundCentres, 
         redforegroundWidth, redforegroundBins,
         greenforegroundHeights, greenforegroundCentres, 
         greenforegroundWidth, greenforegroundBins);
  mxFree(centre);
  mxFree(xradius);
  mxFree(yradius);

}









