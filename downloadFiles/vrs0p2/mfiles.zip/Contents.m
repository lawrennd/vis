% VIS toolbox
% Version 0.2 Tuesday, June 24, 2003 at 19:20:54
% Copyright (c) 2002, 2003 Neil D. Lawrence
% $Revision: 0.2 $
% 
% DEMOPAPER1 This script recreates a Bioinformatics paper experiment.
% DEMOPAPER2 This script recreates a Bioinformatics paper experiment.
% DEMOPAPER3 This script recreates a Bioinformatics paper experiment.

% DEMOSAMPLE This script visualises the algorithm as it runs.
% DEMOTWO This is a demo of the variational importance sampler on a small grid.
% EXTRACTRATIOS Function for extracting log ratios associated with ovals.
% HISTOGCREATE Creates a histogram between a specified range.
% INDHISTOGLL Compute the log-likelihood of a histogram, assuming data is indpendently sampled.

% MICROARRAYOVALS This function does the variational importance sampling

% OBJECTDELETE Clear up the graphics that portray an object.
% OVALCREATE Create a struct containing the parameters of an oval.
% OVALDRAW Function for drawing an oval from an array of oval structures.
% OVALLL Evaluate the log likelihood of hypothesised ovals.
% OVALSAMPLE Sample an oval.
% OVALSUBSCRIPT Returns the subscripts of any pixels that would fall inside the oval
% PREPAREPLOT Helper function for tidying up the plot before printing.
% PROCESSIMAGE This function processes a cDNA microarray image,
% PWHIST Create a histogram based on values with an associated posterior probability.
% PWHISTOGCREATE Create a histogram using posterior weighted inputs.
% RATIOCSVWRITE Takes a structure giving results and writes to a csv file.
% SAGGRID2OVALS Converts a saggrid into ovals.
% SAGREAD This function loads a scanalyze SAG file into a structure in matlab
% SAGGRIDPOINTS Extracts the centres of the ovals from scanalyze grids.
% SAGWRITE this function takes a grid from matlab and writes it to a scanalyze grid file.
% SCANALYZELOG2 Helper function to get log2 ratio from a scanalyze file
% SPOTLOG2 Helper function to get log2 ratio from a spot file.
% ZEROAXES A function to move the axes crossing point to the origin.
