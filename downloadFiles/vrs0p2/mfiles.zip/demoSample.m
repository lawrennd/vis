% DEMOSAMPLE This script visualises the algorithm as it runs.
% This script runs the vis algorithm on the first grid visualising the
% samples as it runs.
clf
[answer, saggrid] = processImage('SS1', 2, 1);