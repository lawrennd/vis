% DEMOTWO This is a demo of the variational importance sampler on a small grid.

HOME = getenv('HOME');

CURRENTIMAGE = imread('demoimage.tif');

redChannel = CURRENTIMAGE(:, :, 1);
greenChannel = CURRENTIMAGE(:, :, 2);
image(CURRENTIMAGE);
I_max = 65535;
axis equal
axis off


%txtTitle = title('Variational Importance Sampling: Demo 2');
%set(txtTitle, 'fontsize', 24);
%set(txtTitle, 'fontname', 'verdana');
horizLine = line([1 200], [95 95; 122 122; 150 150]);
vertLine = line([29 29; 54 54; 79 79; 104 104; 129 129; 154 154; 179 ...
		179], [1 200]);

color = get(horizLine(1), 'color');
color = [1 0 1];
set(horizLine, 'linewidth', 1, 'linestyle', '--', 'color', color);
set(vertLine, 'linewidth', 1, 'linestyle', '--', 'color', color);

numSamps = 200;

centreSD = 1.5; % The standard deviation of centres prior
centrePrior.beta = 1/(centreSD*centreSD);    % The precision of the centres prior
centrePrior.S_inv = eye(2); % The covariance of the centre's wishart distribution
centrePrior.nu = 8;         % The degrees of freedom of the centre's wishart distribution

correlatedRadiusSD = 2; % The standard deviation of centres prior
anticorrelatedRadiusSD = 1;
eigVectors = [sqrt(2)/2 sqrt(2)/2; sqrt(2)/2 -sqrt(2)/2];
eigVals = 1./[correlatedRadiusSD^2 anticorrelatedRadiusSD^2];
radiusPrior.precision = eigVectors*diag(eigVals)*eigVectors';      % The precision of the radii prior 
radiusPrior.S_inv = eye(2); % The inverse covariance of the radii's wishart distribution
radiusPrior.nu  = 8;        % The degrees of freedom of the centre's wishart distribution
radiusPrior.mu = [10 10];
maxWidth = 20; % THe maximum width of a spot
maxHeight = 20; % The maximum height of a spot

display = 2;
maxIters = 10;
xRange = [54:25:154];
yRange  = [95 122 150];
counter = 0;
for y = yRange
  for x = xRange
    counter = counter + 1;
    origOvals(counter) = ovalcreate([x y], radiusPrior.mu(1), radiusPrior.mu(2));
    origOvals(counter).selected = 0;
    origOvals(counter) = ovaldraw(origOvals(counter));
    set(origOvals(counter).handle, 'linestyle', ':', 'color', [1 0 1])
  end
end
disp('Press any key')
pause

% Calculate a top right and bottom left point of a rectangle 
% that includes the parallelogram representing the grid
rows = 3;
cols = 7;
firstPoint(1) = min(xRange);
firstPoint(2) = min(yRange);
secondPoint(1) = max(xRange);
secondPoint(2) = max(yRange);

% These indices are those of all pixels within the initial ovals.
[iFore jFore] = ovalsubscript(origOvals);

set(gca, 'xlim', [firstPoint(1) - maxWidth secondPoint(1) + maxWidth])
set(gca, 'ylim', [firstPoint(2) - maxWidth secondPoint(2) + maxWidth])

% These indices are those of all pixels within the grid.
jPoints = round(firstPoint(1)-maxWidth):round(secondPoint(1)+maxWidth);
iPoints = round(firstPoint(2)-maxWidth):round(secondPoint(2)+maxWidth);
[iFull,  jFull] = meshgrid(iPoints, jPoints);
iFull = iFull(:);
jFull = jFull(:);
fullIndex = sub2ind(size(redChannel), iFull, jFull);

% Compute the corners of the grid
topRight = [min(jFull) min(iFull)];
bottomLeft = [max(jFull) max(iFull)];
gridSize = bottomLeft - topRight + 1;

% Get the indices of the grid which are foreground
gridForeIndices = sub2ind(gridSize, ...
			  jFore - topRight(1) + 1, ...
			  iFore - topRight(2) + 1); 


% Extract the red data
redX = redChannel(fullIndex);

% Extract the green data
greenX = greenChannel(fullIndex);

% Label according to foreground/background
t = zeros(size(redX));
t(gridForeIndices) = 1;

% Index the foreground and background
backIndex = find(t==0);
foreIndex = find(t==1);

% Extract the red background image pixels and histogram.
redbackHist = histogcreate(double(redX(backIndex)), 0, I_max, 50);
redbackHist.height = (redbackHist.height*length(foreIndex) + ...
		      1/(I_max*redbackHist.width)) ...
    /(length(foreIndex) + 1);

% Extract the green background image pixels and histogram.
greenbackHist = histogcreate(double(greenX(backIndex)), 0, I_max, 50);
greenbackHist.height = (greenbackHist.height*length(backIndex) + ...
			1/(I_max*greenbackHist.width)) ...
    /(length(backIndex) + 1);

% Extract the red foreground image pixels and histogram.
redforeHist = histogcreate(double(redX(foreIndex)), 0, I_max, 50);
redforeHist.height = (redforeHist.height*length(foreIndex) + ...
		      1/(I_max*redforeHist.width)) ...
    /(length(foreIndex) + 1);

% Extract the green foreground image pixels and histogram.
greenforeHist = histogcreate(double(greenX(foreIndex)), 0, I_max, 50);
greenforeHist.height = (greenforeHist.height*length(foreIndex) + ...
			1/(I_max*greenforeHist.width)) ...
    /(length(foreIndex) + 1);

movieCounter = 0;
M=[];
for y = yRange
  for x = xRange
    centrePrior.mu = [x y];  % The mean of the centres prior
    [ovals, importanceWeights, M, movieCounter] = microarrayOvalsMovie(redChannel, greenChannel, ...
						 centrePrior, radiusPrior, ...
						 maxWidth, maxHeight, ...
						 redbackHist, greenbackHist, ...
						 redforeHist, greenforeHist, ...
						 numSamps, display, ...
						 maxIters, 0, M, movieCounter);

  end
end


M(movieCounter + 1) = getframe;












