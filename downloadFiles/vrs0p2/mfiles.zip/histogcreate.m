function [histog, logLikelihood]= histogcreate(data, start, finish, nbins)

% HISTOGCREATE Creates a histogram between a specified range.
%
% [histog, logLikelihood]= histogcreate(data, start, finish, nbins)
%
% Copyright (c) Neil Lawrence 2001

histog.ncentres = nbins;
histog.width = (finish - start)/(nbins);
histog.centres = (start+histog.width/2:histog.width:finish-histog.width/2);
[histog.height, histog.centres] = hist(data, histog.centres);
histog.height = histog.height/sum(histog.height);
histog.height = histog.height/histog.width;
if nargout > 1
  logLikelihood  =log( histogprob(histog, data));
end
if nargout == 0
  bar(histog.centres, histog.height);
end
