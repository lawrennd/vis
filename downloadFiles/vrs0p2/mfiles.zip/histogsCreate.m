function  [redbackHistog, greenbackHistog, redforeHistog, greenforeHistog, posteriorForex] = ...
      histogsCreate(redX, greenX, start, finish, numBins, t);

priorFore = 0.3;
priorBack = 0.9;

posteriorFore = zeros(size(t));
posteriorFore(find(t)) = priorFore;
posteriorFore(find(~t)) = 1-priorBack;
posteriorBack = 1-posteriorFore;

figure(3)
a1 = subplot(2, 1, 1);
a2 = subplot(2, 1, 2);
for i = 1:10
  axes(a1)
  %    colormap(mycolormap{plotCol})
  redforeHistog = pwhistogcreate(redX, start, finish, numBins, posteriorFore);
  greenforeHistog = pwhistogcreate(greenX, start, finish, numBins, posteriorFore);
  redbackHistog = pwhistogcreate(redX, start, finish, numBins, posteriorBack); 
  greenbackHistog = pwhistogcreate(greenX, start, finish, numBins, posteriorBack); 
  bar(redforeHistog.centres', ...
      [redbackHistog.height; redforeHistog.height]');
  if i == 1
    title('Red Histograms')
  else
    title(['Red Histograms: Iteration ' num2str(i-1)])
  end
  ylim1 = get(a1, 'ylim');
  
  axes(a2)
  %    colormap(mycolormap{plotCol})
  bar(greenforeHistog.centres', ...
      [greenbackHistog.height; greenforeHistog.height]');

  if i == 1
    title('Green Histograms')
  else
    title(['Green Histograms: Iteration ' num2str(i-1)])
  end
  ylim1 = get(a1, 'ylim');
  ylim2 = get(a2, 'yLim');
  ylim = [0 max([ylim2(2) ylim1(2)])];
  set(a1, 'ylim', ylim)
  set(a2, 'ylim', ylim)
  
  vals = linspace(0, 1, numBins*3);
  foreForell = indHistogll(redforeHistog, redX(find(t==1))) ...
      + indHistogll(greenforeHistog, greenX(find(t==1)));
  backForell = indHistogll(redbackHistog, redX(find(t==1))) ...
      + indHIstogll(greenbackHistog, greenX(find(t==1)));
  
  
  posteriorFore(find(t==1)) = priorFore*exp(foreForell)./(priorFore*exp(foreForell) + (1- ...
						  priorFore)*exp(backForell));
  
  foreBackll = indHistogll(redforeHistog, redX(find(t==0))) ...
      + indHistogll(greenforeHistog, greenX(find(t==0)));
  backBackll = indHistogll(redbackHistog, redX(find(t==0))) ...
      + indHIstogll(greenbackHistog, greenX(find(t==0)));
  
  posteriorFore(find(t==0)) = priorFore*exp(foreBackll)./(priorFore*exp(foreBackll) + (1- ...
						  priorFore)*exp(backBackll));
  
  posteriorBack = 1-posteriorFore;
  %priorFore = mean(posteriorFore(find(t==1)));
  max(posteriorFore)
  drawnow
  %figure
  if i < 6
    %pause
  end
  %plot(vals, pFore);
end
