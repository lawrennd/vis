HOME = getenv('HOME');

addpath([HOME '/mlprojects/bayesianMicroarrayImage/matlab']);
addpath([HOME '/mlprojects/matlab/netlab']);
addpath([HOME '/mlprojects/matlab/general']);
addpath([HOME '/mlprojects/matlab/drawing']);

CURRENTIMAGE = imread('demoimage2.tif');

imageData = max(CURRENTIMAGE, [], 3);
image(CURRENTIMAGE);
axis equal
axis off

txtTitle = title('Variational Importance Sampling: Demo 1')
set(txtTitle, 'fontsize', 24);
set(txtTitle, 'fontname', 'verdana');

horizLine = line([1 35], [25 25]);
vertLine = line([15 15], [1 43]);
color = get(horizLine(1), 'color');
set(horizLine, 'linewidth', 1, 'linestyle', '--', 'color', color);
set(vertLine, 'linewidth', 1, 'linestyle', '--', 'color', color);

lowerBackground = 6500;
upperBackground= 7500;
dustSpotPoint = 65035;
numSamps = 200;

centrePrior.beta = .125; % The precision of the centres prior
centrePrior.S_inv = 1*eye(2); % The covariance of the centre's wishart distribution
centrePrior.nu = 2;% The degrees of freedom of the centre's wishart distribution
radiusPrior.mu = [10 10];  % The mean of the radii prior
radiusPrior.beta = .125; % The precision of the radii prior 
radiusPrior.S_inv = 1*eye(2); % The inverse covariance of the radii's wishart distribution
radiusPrior.nu  = 2;% The degrees of freedom of the centre's wishart distribution

maxWidth = 25; % THe maximum width of a spot
maxHeight = 25; % The maximum height of a spot

display = 2;
maxIters = 20;
pause
for x = 15
  for y = 25
    centrePrior.mu = [x y];  % The mean of the centres prior
[ovals, importanceWeights] = microarrayOvals(imageData, centrePrior, radiusPrior, ...
					     maxWidth, maxHeight, ...
					     lowerBackground, upperBackground, ...
					     dustSpotPoint, ...
					     numSamps, display, maxIters, ...
					     1);
  end
end









