function [n, centres, width, below, above] = pwhist(data, start, finish, nbins, posterior)

% PWHIST Create a histogram based on values with an associated posterior probability.

LOGOFZERO = -328.0;

width = (finish - start)/(nbins);
% Sort in ascending order
numData = length(data);
[sortData, sortIndex] = sort(data);
sortPosterior = posterior(sortIndex);
centres = start + width/2 + width*(0:nbins);
i = 1;
binNo = 1;
while i <= numData & sortData(i) < centres(binNo) - width/2;
  i = i + 1;
end
below = sum(sortPosterior(1:i-1));
lasti = i;

while binNo <= length(centres)
  binEnd = centres(binNo) + width/2;
  while(i <= numData & sortData(i) < binEnd) 
    i = i + 1;
  end
  n(binNo) = sum(sortPosterior(lasti:i-1));
  lasti = i;
  binNo = binNo + 1;
end

if lasti ~= length(sortData)
  above = sum(sortPosterior(lasti:end));
end

