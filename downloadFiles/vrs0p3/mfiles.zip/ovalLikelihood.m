function ll = ovalLikelihood(params, oval, likelihoodStruct);

% OVALLIKELIHOOD Computes the likelihood of an oval given an integral image.

for i = 1:size(params, 1)
  ovals(i) = ovalpak(params(i, :), oval);
end
% Call c++ function for speed.
ll = ovalll(ovals, likelihoodStruct);
