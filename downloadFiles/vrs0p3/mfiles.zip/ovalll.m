function sampl = ovalll(ovals, limitsx, limitsy,  redChannel, greenChannel, redbackHist, ...
		     greenbackHist, redforeHist, greenforeHist)

% OVALLL Evaluate the log likelihood of hypothesised ovals.
%
% sampl = ovalll(ovals, limitsx, limitsy, redChannel, greenChannel,
% redbackHist, greenbackHist, redforeHist, greenforeHist)
% ovals --- structure containing ovals to evaluate.
% limitsx and limitsy --- the region of the image in which the oval is
% expected.
% redChannel --- the red channel from the array image
% greenChannel --- the green channel from the array image
% redbackHist --- a histogram representing the red background
% greenbackHist --- a histogram representing the green background
% redforeHist --- a histogram representing the red foreground
% greenforeHist --- a histogram representing the green foreground
%
% This function is implemented as a mex file. See ovalll.cpp
%
% version 0.1 
% Copyright (c) Neil Lawrence 2002
