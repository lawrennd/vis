function [saggrid, ovals] = saggridVISampler(saggrid, likelihoodStruct, display, ovals); 
  
% SAGGRIDVISAMPLER Use the variational importance sampler to refine the grid position.

% 
% version 0.3 
% Copyright (c) Neil Lawrence 2003


numSamps = 100;

params = saggridunpak(saggrid);

% Group 1 is the corner positions.
priors{1}.mu = params(1:6);
cornersSD = 3; % The standard deviation of corners prior
priors{1}.precision ...
    = 1/(cornersSD*cornersSD)*eye(6);    % The precision of the corners' prior
priors{1}.nu = 10;         % The degrees of freedom of the corners' wishart distribution
priors{1}.S_inv = 0.1*eye(6)*priors{1}.nu; % The scale matrix of the corner's wishart distribution

% Group 2 is the widths of the spots
priors{2}.mu = params(7:8);
correlatedWidthSD = 4; % The standard deviation of the radiicentres prior
anticorrelatedWidthSD = 2;
eigVectors = [sqrt(2)/2 sqrt(2)/2; sqrt(2)/2 -sqrt(2)/2];
eigVals = 1./[correlatedWidthSD^2 anticorrelatedWidthSD^2];
priors{2}.precision = eigVectors*diag(eigVals)*eigVectors';      % The
                                                                 % precision
                                                                 % of the
                                                                 % radii
                                                                 % prior 								 
priors{2}.nu = 3;        % The degrees of freedom of the centre's wishart distribution
priors{2}.S_inv = 0.1*eye(2)*priors{2}.nu; % The scale matrix of the radii's wishart distribution

maxIters = 20;              % Maximum number of iterations for each spot
numSamps = 100;

% create integral image
integralLikelihood = intStructImage(likelihoodStruct);

options(1) = display;
options(2) = numSamps; % Number of Samples
options(3) = maxIters;              % Maximum number of iterations
options(4) = 10; % max iterations in the inner (quicker) loop

% group One is the corner positions, group 2 is the widths
[samples, weights] = viSampler('saggridLikelihood', [ones(1, 6) ones(1, 2)*2], ...
			       options, priors, ...
			       saggrid, integralLikelihood); 
params = weights*samples;  
saggrid = saggridpak(params, saggrid);
ovals = saggrid2oval(saggrid);
  
function intStruct = intStructImage(intStruct);

% INTSTRUCTIMAGE COmpute integral image for the components of the structure.

intStruct.gridForeLl = intImage(intStruct.gridForeLl);
intStruct.gridBackLl = intImage(intStruct.gridBackLl);


function imageVals = intImage(imageVals);

% INTIMAGE Compute an integral image

imageVals(1, :) = cumsum(imageVals(1, :));
for i = 2:size(imageVals, 1)
  imageVals(i, :) = cumsum(imageVals(i, :)) + imageVals(i-1, :);
end

