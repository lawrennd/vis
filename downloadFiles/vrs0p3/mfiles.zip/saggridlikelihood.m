function ll = saggridLikelihood(gridParams, grid, intLike);

% SAGGRIDLIKELIHOOD Computes the likelihood of the grid given an integral image.

% Inputs --- integralImage -- image containing integral image from the
% foreground - integral image from the background.

% minCol ---- the position in the full image of the first column in the
% integral image.

% minRow --- the position in the full image of the first row in the
% integral image.

for i = 1:size(gridParams, 1)
  grids(i) = saggridpak(gridParams(i, :), grid);
end
for gridNo = 1:length(grids)
  ll(gridNo) = 0;
  % Make a box of same area as circle
  boxXRadius = grids(gridNo).spotWidth/2*pi/4;
  boxYRadius = grids(gridNo).spotHeight/2*pi/4;
  centrePoints = saggridpoints(grids(gridNo));
  centrePoints(:, 1) = centrePoints(:, 1) - intLike.minCol+1;
  centrePoints(:, 2) = centrePoints(:, 2) - intLike.minRow+1;
  leftPoints = round(centrePoints(:, 1) - boxXRadius);
  topPoints = round(centrePoints(:, 2) - boxYRadius);
  rightPoints = round(centrePoints(:, 1) + boxXRadius);
  bottomPoints = round(centrePoints(:, 2) + boxYRadius);

  for i = 1:length(leftPoints)
    try
      ll(gridNo) = ll(gridNo) ...
	  + intLike.gridForeLl(topPoints(i)-1, leftPoints(i)-1) ...
	  - intLike.gridForeLl(topPoints(i)-1, rightPoints(i)) ...
	  - intLike.gridForeLl(bottomPoints(i), leftPoints(i)-1) ...
	  + intLike.gridForeLl(bottomPoints(i), rightPoints(i));
      ll(gridNo) = ll(gridNo) ...
	  - intLike.gridBackLl(topPoints(i)-1, leftPoints(i)-1) ...
	  + intLike.gridBackLl(topPoints(i)-1, rightPoints(i)) ...
	  + intLike.gridBackLl(bottomPoints(i), leftPoints(i)-1) ...
	  - intLike.gridBackLl(bottomPoints(i), rightPoints(i));
    catch
      err = lasterror;
      if(strcmp(err.identifier, 'MATLAB:badsubscript'))
	ll(gridNo) = ll(gridNo) - 1e6*grids(gridNo).spotHeight* ...
	    grids(gridNo).spotWidth;
      else
	rethrow(lasterror);
      end
    end
  end
end
