function grid = saggridpak(params, grid)

% SAGGRIDPAK Takes the parameters of a set of grids and returns the grid
% structures.

left = params(1, 1);
top = params(1, 2);
tleft = [left top];
bleft = [params(1, 3) params(1, 4)];
bright = [params(1, 5) params(1, 6)];
grid.type = 'saggrid';
grid.spotWidth = params(1, 7); 
grid.spotHeight = params(1, 8);
grid.left = left;
grid.top = top;
grid.colX = (bright(1) - bleft(1))/(grid.columns-1);
grid.colY = (bright(2) - bleft(2))/(grid.columns-1);
grid.rowX = (bleft(1) - tleft(1))/(grid.rows-1);
grid.rowY = (bleft(2) - tleft(2))/(grid.rows-1);
grid.rowOffset = zeros(grid.rows, grid.columns);
grid.columnOffset = zeros(grid.rows, grid.columns);
grid.widthOverride = zeros(grid.rows, grid.columns);
grid.heightOverride = zeros(grid.rows, grid.columns);
grid.flag = zeros(grid.rows, grid.columns);  
