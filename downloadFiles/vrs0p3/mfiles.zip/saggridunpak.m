function params = saggridunpak(grids)

% SAGGRIDUNPAK Take an array of grids and convert into a matrix of their parameters.

numGrids = length(grids);
params = zeros(numGrids, 8);

for i = 1:length(grids)
  left = grids(i).left;
  top = grids(i).top;
  tleft = [left top];
  bleft = tleft + [(grids(i).rows-1)*grids(i).rowX ...
		   (grids(i).rows-1)*grids(i).rowY];
  bright = bleft + [(grids(i).columns-1)*grids(i).colX ...
		    (grids(i).columns-1)*grids(i).colY];

  params(i, 1:6) = [tleft bleft bright];
  params(i, 7:8) = [grids(i).spotWidth grids(i).spotHeight];
end
